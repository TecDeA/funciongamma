/* Service Worker - Calculadora y Visualizador de la Función Gamma
   v1.2.0 - Soporte offline y actualizaciones controladas. */
const VERSION = '1.2.0';
const CACHE_NAME = `gamma-fn-${VERSION}`;

const PRECACHE = [
    './',
    './index.html',
    './manifest.json',
    './img/favicon.ico',
    './img/favicon-16.png',
    './img/favicon-32.png',
    './img/apple-touch-icon.png',
    './img/icon-64.png',
    './img/icon-192.png',
    './img/icon-512.png',
    './img/icon-maskable-512.png'
];

self.addEventListener('install', (event) => {
    event.waitUntil((async () => {
        const cache = await caches.open(CACHE_NAME);
        // Precarga tolerante: un recurso que falte no aborta la instalación
        await Promise.allSettled(PRECACHE.map((url) =>
            cache.add(new Request(url, { cache: 'reload' }))
        ));
        await self.skipWaiting();
    })());
});

self.addEventListener('activate', (event) => {
    event.waitUntil((async () => {
        const keys = await caches.keys();
        await Promise.all(
            keys
                .filter((k) => k.startsWith('gamma-fn-') && k !== CACHE_NAME)
                .map((k) => caches.delete(k))
        );
        await self.clients.claim();
    })());
});

self.addEventListener('fetch', (event) => {
    const req = event.request;
    if (req.method !== 'GET') return;

    const url = new URL(req.url);

    // Navegaciones (HTML): red primero, caché como respaldo offline
    if (req.mode === 'navigate') {
        event.respondWith((async () => {
            try {
                return await fetch(req);
            } catch (err) {
                const cache = await caches.open(CACHE_NAME);
                return (await cache.match('./index.html'))
                    || (await cache.match('./'))
                    || Response.error();
            }
        })());
        return;
    }

    // Resto de recursos (CDNs incluidos): red primero, caché de respaldo
    event.respondWith((async () => {
        const cache = await caches.open(CACHE_NAME);
        try {
            const fresh = await fetch(req);
            if (fresh && (fresh.ok || fresh.type === 'opaque')) {
                cache.put(req, fresh.clone()).catch(() => {});
            }
            return fresh;
        } catch (err) {
            const cached = await cache.match(req, { ignoreVary: true });
            if (cached) return cached;
            throw err;
        }
    })());
});

// Protocolo de versión usado por index.html (chip "v1.2.0")
self.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'GET_VERSION' && event.source) {
        event.source.postMessage({ type: 'VERSION', version: VERSION });
    }
});
